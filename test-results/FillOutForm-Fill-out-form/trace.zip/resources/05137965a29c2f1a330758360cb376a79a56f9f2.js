function convertStoreSubscriberIDInCookie(subscriber_id){if(convertkit.debug){console.log('convertStoreSubscriberIDInCookie');console.log(subscriber_id)}
fetch(convertkit.ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',},body:new URLSearchParams({action:'convertkit_store_subscriber_id_in_cookie',convertkit_nonce:convertkit.nonce,subscriber_id:subscriber_id})}).then(function(response){if(convertkit.debug){console.log(response)}
return response.json()}).then(function(result){if(convertkit.debug){console.log(result)}
convertKitRemoveSubscriberIDFromURL(window.location.href)}).catch(function(error){if(convertkit.debug){console.error(error)}
convertKitRemoveSubscriberIDFromURL(window.location.href)})}
function convertStoreSubscriberEmailAsIDInCookie(emailAddress){if(convertkit.debug){console.log('convertStoreSubscriberEmailAsIDInCookie');console.log(emailAddress)}
fetch(convertkit.ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',},body:new URLSearchParams({action:'convertkit_store_subscriber_email_as_id_in_cookie',convertkit_nonce:convertkit.nonce,email:emailAddress})}).then(function(response){if(convertkit.debug){console.log(response)}
return response.json()}).then(function(result){if(convertkit.debug){console.log(result)}
convertKitEmitCustomEvent('convertkit_user_subscribed',{id:result.data.id,email:emailAddress})}).catch(function(error){if(convertkit.debug){console.error(error)}})}
function convertKitRemoveSubscriberIDFromURL(url){const url_object=new URL(url);url_object.searchParams.delete('ck_subscriber_id');const title=document.getElementsByTagName('title')[0].innerHTML;let params=url_object.searchParams.toString();if(params.length>0){params='?'+params}
window.history.pushState(null,title,url_object.pathname+params)}
function convertKitSleep(milliseconds){var start=new Date().getTime();for(var i=0;i<1e7;i++){if((new Date().getTime()-start)>milliseconds){break}}}
function convertKitEmitCustomEvent(eventName,detail){const event=new CustomEvent(eventName,{detail});document.dispatchEvent(event)}
document.addEventListener('DOMContentLoaded',function(){if(convertkit.subscriber_id>0){convertStoreSubscriberIDInCookie(convertkit.subscriber_id)}
document.addEventListener('click',function(e){if(!e.target.matches('.formkit-submit')&&(!e.target.parentElement||!e.target.parentElement.matches('.formkit-submit'))){if(convertkit.debug){console.log('not a ck form')}
return}
let emailAddress=document.querySelector('input[name="email_address"]').value;if(!emailAddress.length){if(convertkit.debug){console.log('email empty')}
return}
var validator=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;if(!validator.test(emailAddress.toLowerCase())){if(convertkit.debug){console.log('email not an email address')}
return}
convertKitSleep(2000);convertStoreSubscriberEmailAsIDInCookie(emailAddress)})})